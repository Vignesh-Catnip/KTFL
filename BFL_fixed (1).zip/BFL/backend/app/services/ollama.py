"""
Invoice extraction via a local Ollama vision model.

Supports:
  - PDF invoices  (converted page-by-page to images via PyMuPDF)
  - Image invoices (JPG / JPEG / PNG / WEBP, sent directly)

The model is called with an 8K context window (num_ctx=8192) so multi-page
/ dense invoices have enough room for both the prompt and the response.

Flow:
    file path
      -> images (PDF pages rendered to PNG, or the image itself)
      -> Ollama /api/generate (vision model, JSON-only response)
      -> strict JSON parsing (handles code fences / stray text / <think> blocks)
      -> field normalization (vendor, invoice_number, invoice_date, po_number,
         tax_code, business_place, currency, subtotal, tax, total, confidence,
         line items)

If EXTRACTION_MODE=demo, a fixed sample invoice is returned instead (used for
testing the rest of the pipeline without needing Ollama running).
"""
import base64
import json
import re
from pathlib import Path

import httpx
from fastapi import HTTPException

from ..config import settings
from .demo_extractor import demo_extract

SUPPORTED_IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
SUPPORTED_PDF_EXTS = {".pdf"}

SYSTEM_PROMPT = """You are an accounts-payable invoice extraction engine.

Read the provided invoice image(s) carefully. If multiple images are given,
they are consecutive pages of the SAME invoice - combine information across
all of them (e.g. header fields usually appear on page 1, line items may
continue across pages).

Return ONLY one valid JSON object. No markdown, no code fences, no
explanations, no reasoning, no extra text before or after the JSON.

If a text value cannot be found, return an empty string "".
If a numeric value cannot be found, return 0.
Never invent or guess a value that is not visibly present on the invoice.

Dates must be formatted YYYY-MM-DD when the invoice date is unambiguous.
Currency should be an ISO currency code when identifiable (default "INR").
All monetary and quantity amounts must be plain numbers (no currency
symbols, no thousands separators).

Return exactly this JSON structure:
{
  "vendor": "",
  "invoice_number": "",
  "invoice_date": "",
  "po_number": "",
  "tax_code": "",
  "business_place": "",
  "currency": "INR",
  "subtotal": 0,
  "tax": 0,
  "total": 0,
  "confidence": 0,
  "lines": [
    {"item": "", "quantity": 0, "tax_code": "", "amount": 0}
  ]
}

Field meaning:
- vendor: the supplier / vendor / "bill from" company name (NOT the buyer)
- invoice_number: the invoice's own reference number
- invoice_date: the date the invoice was issued
- po_number: purchase order / reference number if printed on the invoice
- tax_code: the invoice's tax code, if the invoice shows one explicitly
- business_place: plant / business place / section, if shown
- subtotal: total before tax
- tax: total tax amount (sum of all tax lines if several are shown)
- total: the final invoice total actually payable
- confidence: your own confidence (0.0-1.0) that the extraction above is
  complete and correct
- lines: every line item on the invoice, with its own quantity/amount
"""


# ---------------------------------------------------------------------------
# Helpers: file -> base64 image(s)
# ---------------------------------------------------------------------------

def _read_image_as_base64(path: Path) -> str:
    if not path.exists():
        raise HTTPException(404, f"Invoice file not found: {path}")
    try:
        image_bytes = path.read_bytes()
    except OSError as exc:
        raise HTTPException(500, f"Could not read invoice image: {exc}") from exc
    if not image_bytes:
        raise HTTPException(400, "Invoice image is empty")
    return base64.b64encode(image_bytes).decode("utf-8")


def _pdf_to_images(path: Path) -> list[str]:
    try:
        import fitz  # PyMuPDF
    except ImportError as exc:
        raise HTTPException(500, "PyMuPDF (pymupdf) is required for PDF extraction") from exc

    if not path.exists():
        raise HTTPException(404, f"Invoice PDF not found: {path}")

    try:
        doc = fitz.open(str(path))
    except Exception as exc:
        raise HTTPException(400, f"Could not open invoice PDF: {exc}") from exc

    images: list[str] = []
    try:
        if doc.page_count == 0:
            raise HTTPException(400, "Invoice PDF has no pages")
        page_limit = max(1, int(settings.ollama_max_pages))
        page_count = min(doc.page_count, page_limit)
        # Render at a moderate resolution: clear enough for OCR-by-vision-model
        # without blowing up the request payload size.
        zoom = fitz.Matrix(1.6, 1.6)
        for page_index in range(page_count):
            page = doc[page_index]
            pixmap = page.get_pixmap(matrix=zoom, alpha=False)
            images.append(base64.b64encode(pixmap.tobytes("png")).decode("utf-8"))
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, f"Could not convert PDF pages to images: {exc}") from exc
    finally:
        doc.close()

    if not images:
        raise HTTPException(400, "No pages could be rendered from invoice PDF")
    return images


def _file_to_images(path: Path) -> list[str]:
    suffix = path.suffix.lower()
    if suffix in SUPPORTED_PDF_EXTS:
        return _pdf_to_images(path)
    if suffix in SUPPORTED_IMAGE_EXTS:
        return [_read_image_as_base64(path)]
    raise HTTPException(
        400, "Unsupported file type. Please upload PDF, JPG, JPEG, or PNG."
    )


# ---------------------------------------------------------------------------
# Helpers: numbers / JSON parsing / field normalization
# ---------------------------------------------------------------------------

def _to_float(value) -> float:
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).replace(",", "")
    cleaned = re.sub(r"[^0-9.\-]", "", text)
    try:
        return float(cleaned) if cleaned else 0.0
    except ValueError:
        return 0.0


def _extract_json(raw_response: str) -> dict:
    if not raw_response or not raw_response.strip():
        raise ValueError("Ollama returned an empty response")

    text = raw_response.strip()
    # Drop any <think>...</think> reasoning blocks some models emit.
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL | re.IGNORECASE).strip()
    # Strip markdown code fences if the model added them despite instructions.
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text).strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("Ollama returned non-JSON output")
    try:
        return json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise ValueError(f"Ollama JSON parsing failed: {exc}") from exc


def _normalize_lines(raw_lines) -> list[dict]:
    lines = []
    if not isinstance(raw_lines, list):
        return lines
    for item in raw_lines:
        if not isinstance(item, dict):
            continue
        lines.append({
            "item": str(item.get("item") or item.get("description") or item.get("name") or "").strip(),
            "quantity": _to_float(item.get("quantity") if item.get("quantity") is not None else item.get("qty")),
            "tax_code": str(item.get("tax_code") or item.get("tax") or "").strip(),
            "amount": _to_float(
                item.get("amount")
                if item.get("amount") is not None
                else (item.get("total") if item.get("total") is not None else item.get("line_total"))
            ),
        })
    return lines


def _normalize(data) -> dict:
    if not isinstance(data, dict):
        data = {}
    inv = data.get("invoice") if isinstance(data.get("invoice"), dict) else data

    raw_lines = inv.get("lines") or inv.get("line_items") or inv.get("items") or []
    lines = _normalize_lines(raw_lines)

    total = _to_float(inv.get("total") if inv.get("total") is not None else inv.get("grand_total"))
    subtotal = _to_float(inv.get("subtotal") if inv.get("subtotal") is not None else inv.get("sub_total"))
    tax = _to_float(inv.get("tax") if inv.get("tax") is not None else inv.get("tax_amount"))

    # If the model only gave line items, derive the totals rather than
    # leaving them at zero (which would fail downstream validation).
    if subtotal == 0 and lines:
        subtotal = sum(line["amount"] for line in lines)
    if total == 0 and (subtotal or tax):
        total = subtotal + tax

    confidence = max(0.0, min(1.0, _to_float(inv.get("confidence"))))

    return {
        "vendor": str(inv.get("vendor") or inv.get("supplier") or inv.get("vendor_name") or "").strip(),
        "invoice_number": str(inv.get("invoice_number") or inv.get("invoiceNumber") or inv.get("invoice_no") or "").strip(),
        "invoice_date": str(inv.get("invoice_date") or inv.get("invoiceDate") or inv.get("date") or "").strip(),
        "po_number": str(inv.get("po_number") or inv.get("poNumber") or inv.get("po") or "").strip(),
        "tax_code": str(inv.get("tax_code") or inv.get("taxCode") or "").strip(),
        "business_place": str(inv.get("business_place") or inv.get("businessPlace") or "").strip(),
        "currency": (str(inv.get("currency") or "INR").strip() or "INR"),
        "subtotal": subtotal,
        "tax": tax,
        "total": total,
        "confidence": confidence,
        "lines": lines,
    }


# ---------------------------------------------------------------------------
# Ollama call
# ---------------------------------------------------------------------------

async def _call_ollama(images: list[str]) -> str:
    endpoint = f"{settings.ollama_url.rstrip('/')}/api/generate"
    payload = {
        "model": settings.ollama_model,
        "prompt": SYSTEM_PROMPT,
        "stream": False,
        "think": False,
        "keep_alive": "30m",
        "images": images,
        "options": {
            # 8K context window: enough for the prompt + a dense multi-line
            # invoice response without truncation.
            "num_ctx": 8192,
            "num_predict": 4096,
        },
    }

    try:
        async with httpx.AsyncClient(timeout=settings.ollama_timeout) as client:
            response = await client.post(endpoint, json=payload)
    except httpx.TimeoutException as exc:
        raise HTTPException(504, "Ollama extraction timed out. Increase OLLAMA_TIMEOUT if required.") from exc
    except httpx.RequestError as exc:
        raise HTTPException(502, f"Could not connect to Ollama at {settings.ollama_url}: {exc}") from exc

    if response.status_code >= 400:
        try:
            error_message = response.json().get("error", response.text)
        except Exception:
            error_message = response.text
        raise HTTPException(502, f"Ollama API returned HTTP {response.status_code}: {error_message}")

    try:
        body = response.json()
    except json.JSONDecodeError as exc:
        raise HTTPException(502, "Ollama returned an invalid API response") from exc

    raw_response = (body.get("response") or "").strip()
    if not raw_response:
        # Some builds route output into "thinking" even with think=False,
        # especially if generation is cut off mid-thought by num_predict.
        raw_response = (body.get("thinking") or "").strip()

    if not raw_response:
        done_reason = body.get("done_reason", "unknown")
        raise HTTPException(
            502,
            "Ollama returned an empty response "
            f"(done_reason={done_reason}). The model may need a higher "
            "OLLAMA num_predict, or does not support this vision workflow.",
        )
    return raw_response


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

async def extract_invoice(file_path: str) -> dict:
    if settings.extraction_mode == "demo":
        return demo_extract(file_path)

    if settings.extraction_mode != "ollama":
        raise HTTPException(500, "EXTRACTION_MODE must be 'demo' or 'ollama'")
    if not settings.ollama_url:
        raise HTTPException(500, "OLLAMA_URL is not configured")
    if not settings.ollama_model:
        raise HTTPException(500, "OLLAMA_MODEL is not configured")

    path = Path(file_path)
    images = _file_to_images(path)  # handles PDF -> pages, or single image

    try:
        raw_response = await _call_ollama(images)
        parsed = _extract_json(raw_response)
        return _normalize(parsed)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(502, f"Could not parse Ollama extraction: {exc}") from exc
    except Exception as exc:
        raise HTTPException(500, f"Unexpected error during Ollama extraction: {exc}") from exc
